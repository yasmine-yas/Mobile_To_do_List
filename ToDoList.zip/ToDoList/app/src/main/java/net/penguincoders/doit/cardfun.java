package net.penguincoders.doit;

public class cardfun
{
    // cardview
       /*
        cv = findViewById(R.id.card_view);
        final CheckBox checkBox = (CheckBox) findViewById(R.id.check);
        checkBox.setText("linah");
        checkBox.setTextColor(getResources().getColor(R.color.black));
        checkBox.setTextSize(20);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if (isChecked){
                    checkBox.setPaintFlags(checkBox.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

                }
                else{
                    checkBox.setPaintFlags(checkBox.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));

                }

            }
        });
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radgrp);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // checkedId is the RadioButton selected
                switch (checkedId) {
                    case R.id.radiobutton_1: // first button

                        cv.setCardBackgroundColor(Color.parseColor("#FFFAA0"));
                        break;
                    case R.id.radiobutton_2:

                        cv.setCardBackgroundColor(Color.parseColor("#B4D3B2"));
                        break;
                    case R.id.radiobutton_3:

                        cv.setCardBackgroundColor(Color.parseColor("#FF9690"));
                        break;
                }


            }


        });*/
}
